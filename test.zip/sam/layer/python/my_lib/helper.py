# layer/python/my_lib/helper.py
def greet(name):
    return f"Hello, {name}!"
