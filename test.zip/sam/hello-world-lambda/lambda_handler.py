def lambda_handler(event, context):
    """
    シンプルなHello World関数
    """
    return {
        'statusCode': 200,
        'body': 'Hello, World'
    }
