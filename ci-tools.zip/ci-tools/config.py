import os

# CI環境かどうかを判定
if os.getenv("CI"):
    GITLAB_PROJECT_ID = os.getenv("CI_PROJECT_ID", "")
    GITLAB_MR_IID = os.getenv("CI_MERGE_REQUEST_IID", "")
    GITLAB_TOKEN = os.getenv("GITLAB_TOKEN", "")
    PMD_PATH = os.getenv("PMD_PATH", "/cache/pmd-bin-7.10.0/bin/pmd")
    EXECUTE_PATH = os.getenv("EXECUTE_PATH", "")
else:
    # ローカル実行時のデフォルト値（または .env ファイルなどで読み込み）
    PMD_PATH = os.getenv(
        "LOCAL_PMD_PATH", r"C:\Users\user\Desktop\work\20250208_gitlab\pmd-dist-7.10.0-bin\pmd-bin-7.10.0\bin\pmd.bat")
    EXECUTE_PATH = os.getenv(
        "LOCAL_EXECUTE_PATH", r"..")
    # HEAD(最後にコミットされた変更)と未コミットの変更(未ステージ&ステージング済み)を比較するためのオプション
    GIT_DIFF_OPTION = os.getenv("GIT_DIFF_OPTION", "HEAD")
    # HEAD(最後にコミットされた変更)とステージングエリアの差分
    # GIT_DIFF_OPTION = os.getenv("GIT_DIFF_OPTION", "--staged")
    # HEAD(最後にコミットされた変更)とステージングエリアの差分
    # GIT_DIFF_OPTION = os.getenv("GIT_DIFF_OPTION", "--staged")
    # HEAD(最後にコミットされた変更)とmainブランチ(ローカル)の差分
    # GIT_DIFF_OPTION = os.getenv("GIT_DIFF_OPTION", "develop")
    # HEAD(最後にコミットされた変更)とリモート(origin/develop)の比較
    # GIT_DIFF_OPTION = os.getenv("GIT_DIFF_OPTION", "origin/develop")
