import config
import os
from modules.gitlab.api_client import GitLabAPIClient
from modules.gitlab.diff_parser import GitLabDiffParser
from modules.gitlab.diff_parser import GitLocalDiffParser
from modules.static_analysis.pmd_executor import PMDExecutor
from processors.static_analysis_processor import StaticAnalysisProcessor
from diff_providers.diff_provider import GitLabDiffProvider
from diff_providers.diff_provider import LocalDiffProvider
from notifiers.notifier import GitLabCommentNotifier, LocalResultNotifier


def static_analysis_main():
    try:
        # CI環境での実効
        if os.getenv("CI"):
            gitlab_api = GitLabAPIClient(
                project_id=config.GITLAB_PROJECT_ID,
                mr_iid=config.GITLAB_MR_IID,
                token=config.GITLAB_TOKEN
            )
            diff_provider = GitLabDiffProvider(gitlab_api, GitLabDiffParser())
            result_notifier = GitLabCommentNotifier(gitlab_api)

        else:
            # ローカル環境での実行
            diff_provider = LocalDiffProvider(GitLocalDiffParser())
            result_notifier = LocalResultNotifier()

        pmd_executor = PMDExecutor(
            pmd_path=config.PMD_PATH,
            src_dir=config.EXECUTE_PATH
        )

        statisAnalysisProcessor = StaticAnalysisProcessor(
            diff_provider=diff_provider,
            result_notifier=result_notifier,
            static_executor=pmd_executor,
            base_dir=config.EXECUTE_PATH
        )
        statisAnalysisProcessor.run()

    except Exception as e:
        print(f"エラーが発生しました: {e}")


if __name__ == "__main__":
    static_analysis_main()
