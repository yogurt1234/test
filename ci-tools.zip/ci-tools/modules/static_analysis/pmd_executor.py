import os
import subprocess
import json


class PMDExecutor:
    def __init__(self, pmd_path: str = r"pmd",  src_dir: str = r"../src"):
        r"""
        :param pmd_path: PMD の実行可能ファイルのパス
        """
        self.pmd_path = pmd_path
        self.src_dir = src_dir

    def execute(self, report_file: str = "report.json") -> str:
        r"""
        PMD を以下のコマンドで実行します:
            pmd check -d <src_dir> -R rulesets/java/quickstart.xml -f json -r report.json

        指定した report_file に JSON 形式のレポートが出力されます。
        PMD は違反が見つかった場合、通常終了コード 4 を返しますので、
        その場合は違反があるとみなして処理を続行します。

        :param report_file: レポート出力先のファイルパス (デフォルトは "report.json")
        :param src_dir: ソースコードディレクトリのパス (デフォルトは r"..\src")
        """
        # src_dir を絶対パスに変換
        abs_src_dir = os.path.abspath(self.src_dir)

        command = [
            self.pmd_path,
            "check",
            "-d", abs_src_dir,
            "-R", r"rulesets/java/quickstart.xml",
            "-f", "json",
            "-r", report_file
        ]

        try:
            # check=False として実行し、終了コードで判断する方法
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False
            )
            # 終了コード 0: 問題なし、4: 違反が見つかったケース
            if result.returncode not in (0, 4):
                print("PMD の実行中に予期せぬエラーが発生しました:")
                print(result.stderr)
                raise subprocess.CalledProcessError(
                    result.returncode, command, result.stdout, result.stderr)
            else:
                with open(report_file, 'r', encoding='utf-8') as f:
                    return json.load(f)

                if result.returncode == 4:
                    print("違反が見つかりました。")

        except subprocess.CalledProcessError as e:
            # ここに到達するのは、予期しない終了コードの場合のみ
            print("PMD の実行中にエラーが発生しました:")
            print(e.stderr)
            raise
