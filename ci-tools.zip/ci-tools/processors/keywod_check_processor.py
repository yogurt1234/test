
class KeywordCheckProcessor():
    pass

    def run():
        pass
