# mr_runner.py
from typing import Optional
from pathlib import Path
from modules.gitlab.api_client import GitLabAPIClient
from modules.gitlab.diff_parser import GitLabDiffParser
from modules.static_analysis.pmd_executor import PMDExecutor
from diff_providers.diff_provider import DiffProvider
from notifiers.notifier import ResultNotifyer


class StaticAnalysisProcessor:

    def __init__(self, diff_provider: DiffProvider, result_notifier: ResultNotifyer,
                 static_executor: PMDExecutor, base_dir: dir):
        """
        :param gitlab_api: GitLab API を操作するためのインスタンス
        :param diff_parser: diff 情報を解析するための DiffParser インスタンス
        :param static_executor: PMD を実行するための StaticAnalysisExecutor インスタンス
        """
        self.diff_provider = diff_provider
        self.result_notifier = result_notifier
        self.static_executor = static_executor
        self.base_dir = Path(base_dir)

    def run(self):
        # DiffParser によって、変更ファイルと変更行番号を抽出
        diff_content = self.diff_provider.get_diff()

        # 各変更ファイルに対して PMD による静的解析を実行
        analysis_output = self.static_executor.execute()

        # 結果を突き合わせる
        violation_location = self._match_violations(
            diff_content, analysis_output)

        self.result_notifier.notify(violation_location)

    def _match_violations(self, diff_content, analysis_output):
        """
        静的解析結果と差分情報を突き合わせます
        """
        violation_location = []
        for file_analysis in analysis_output.get("files", []):
            abs_filename = file_analysis.get("filename", "")
            relative_path = self._get_relative_path(abs_filename)
            if relative_path is None:
                print(f"ファイルパス {abs_filename} から相対パスの変換に失敗しました。")
                continue

            if relative_path not in diff_content:
                continue

            for violation in file_analysis['violations']:
                if not violation['beginline'] in diff_content[relative_path]['changed_lines']:
                    continue

                violation_location.append(
                    (diff_content, violation, relative_path))
        return violation_location

    def _get_relative_path(self, abs_path: str) -> Optional[str]:
        """
        絶対パスから、コンストラクタで設定されたbase_dirに対する相対パスを返す。
        変換に失敗した場合は None を返す。
        """
        try:
            # base_dir と abs_path の両方を正規化
            base_dir_obj = Path(self.base_dir).resolve()
            abs_path_obj = Path(abs_path).resolve()

            # base_dir に対して相対パスを取得
            relative_path_obj = abs_path_obj.relative_to(base_dir_obj)

            return relative_path_obj.as_posix()
        except ValueError as e:
            print(f"Error converting {abs_path} to relative path: {e}")
            return None
